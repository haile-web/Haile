from flask import Flask, request, render_template, redirect, url_for, session, flash, jsonify, g
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime,timedelta
import mysql.connector
from mysql.connector import Error
import os
import re
import sys

app = Flask(__name__, static_url_path='/static')
app.secret_key = os.urandom(24)  # Replace 'your_secret_key' with a secure, random string

# MySQL database configuration
db_config = {
    'host': 'localhost',  # Replace with your MySQL host
    'user': 'root',  # Replace with your MySQL username
    'password': 'Ha@12232119',  # Replace with your MySQL password
    'database': 'clearance_system'  # Replace with your MySQL database name
}

def get_db():
    if 'db' not in g:
        try:
            g.db = mysql.connector.connect(**db_config)
        except Error as e:
            print(f"Error connecting to MySQL: {e}")
            sys.exit(1)
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

# Initialize database and create tables
with app.app_context():
    db = get_db()
    cursor = db.cursor()
    try:
        # Create departments table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS departments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) UNIQUE NOT NULL,
            type ENUM('student', 'staff') NOT NULL
        )''')

        # Create users table
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,  -- Auto-incrementing primary key
            id_number VARCHAR(50) UNIQUE,       -- Unique constraint for id_number
            username VARCHAR(255) NOT NULL,
            sex VARCHAR(10),
            password VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL,
            is_active TINYINT DEFAULT 1,
            department_id INT,
            class_year VARCHAR(10),
            last_attended DATE,
            reason TEXT,
            FOREIGN KEY (department_id) REFERENCES departments(id)
        )''')

        # Create clearance_requests table
        cursor.execute('''CREATE TABLE IF NOT EXISTS clearance_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            department_id INT NOT NULL,
            status VARCHAR(50) DEFAULT 'Pending',
            date_of_approval DATE,
            approver_id INT,
            last_date_class_attended DATE,
            reason_for_clearance TEXT NOT NULL,
            comments TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,           
            FOREIGN KEY (student_id) REFERENCES users(id),
            FOREIGN KEY (department_id) REFERENCES departments(id),
            FOREIGN KEY (approver_id) REFERENCES users(id)
        )''')

        # Create notifications table
        cursor.execute('''CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            message TEXT NOT NULL,
            is_read TINYINT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )''')

        db.commit()
    except Error as e:
        print(f"Database error: {e}")
        sys.exit(1)

# Helper functions
def hash_password(password):
    return generate_password_hash(password)

def verify_password(password, hashed_password):
    return check_password_hash(hashed_password, password)

def create_notification(user_id, message):
    try:
        db = get_db()
        cursor = db.cursor()
        cursor.execute('INSERT INTO notifications (user_id, message) VALUES (%s, %s)', (user_id, message))
        db.commit()
    except Error as e:
        print(f"Error creating notification: {e}", file=sys.stderr)

def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if session.get('role') != role:  # Check if the user's role matches the required role
                return "Access denied."
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/help')
def help():
    return render_template('help.html')

@app.route('/get_departments_by_type')
def get_departments_by_type():
    import logging
    logging.basicConfig(level=logging.DEBUG)

    dept_type = request.args.get('type')
    logging.debug(f"Department type requested: {dept_type}")

    if not dept_type:
        return jsonify({"error": "Department type is required"}), 400

    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        # Ensure the department type is valid
        if dept_type not in ['student', 'staff']:
            return jsonify({"error": "Invalid department type. Must be 'student' or 'staff'."}), 400

        # Fetch departments based on the type
        cursor.execute('SELECT id, name FROM departments WHERE type = %s', (dept_type,))
        departments = cursor.fetchall()

        # Check if no departments are found
        if not departments:
            return jsonify({"error": "No departments found for the specified type."}), 404

        return jsonify(departments)
    except Error as e:
        logging.error(f"Error fetching departments: {str(e)}")
        return jsonify({"error": f"Error fetching departments: {str(e)}"}), 500

import logging
logging.basicConfig(level=logging.DEBUG)

@app.route('/home')
def home():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    # Check the number of registered admins
    cursor.execute('SELECT COUNT(*) AS admin_count FROM users WHERE role = "admin"')
    result = cursor.fetchone()
    admin_count = result['admin_count'] if result else 0
    max_admins_reached = admin_count >= 1  # Adjust the limit as needed

    return render_template('home.html', max_admins_reached=max_admins_reached)

# Add other routes here...
@app.route('/register_admin', methods=['GET', 'POST'])
def register_admin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            return render_template('register_admin.html', error_message="Passwords do not match!")

        hashed_password = generate_password_hash(password)  # Hash the password
        db = get_db()
        cursor = db.cursor()

        try:
            # Check the number of existing admin accounts
            cursor.execute('SELECT COUNT(*) FROM users WHERE role = %s', ('admin',))
            admin_count = cursor.fetchone()[0]
            if admin_count >= 1:
                return render_template('register_admin.html', error_message="The system already has an admin account!")

            # Check if the username already exists
            cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
            user = cursor.fetchone()
            if user:
                return render_template('register_admin.html', error_message="Username already exists!")

            # Insert the admin into the database
            cursor.execute('INSERT INTO users (username, password, role) VALUES (%s, %s, %s)', 
                           (username, hashed_password, 'admin'))
            db.commit()
            return render_template('register_admin.html', success_message="Admin registered successfully!")
        except Error as e:
            return render_template('register_admin.html', error_message=f"Error registering the admin: {e}")

    return render_template('register_admin.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    # Track login attempts and block time per username, not globally
    if 'login_attempts' not in session:
        session['login_attempts'] = {}
    if 'login_block_until' not in session:
        session['login_block_until'] = {}

    username = request.form['username'] if request.method == 'POST' else None

    # Only check block for the username being attempted
    block_until = None
    if username:
        block_until = session['login_block_until'].get(username)
        if block_until:
            if isinstance(block_until, str):
                block_until_dt = datetime.strptime(block_until, "%Y-%m-%d %H:%M:%S")
            else:
                block_until_dt = block_until
            if datetime.now() < block_until_dt:
                remaining = (block_until_dt - datetime.now()).seconds // 60 + 1
                return render_template(
                    'login.html',
                    error_message=f"Maximum login attempts reached for this user. Please try again after {remaining} minute(s) or contact the administrator."
                )
            else:
                # Block expired, reset attempts for this user
                session['login_block_until'].pop(username, None)
                session['login_attempts'][username] = 0

    if request.method == 'POST':
        password = request.form['password']
        db = get_db()
        cursor = db.cursor(dictionary=True)

        # Initialize attempts for this username if not present
        if username not in session['login_attempts']:
            session['login_attempts'][username] = 0

        # If max attempts reached for this username, block login for 1 hour
        if session['login_attempts'][username] >= 5:
            session['login_block_until'][username] = (datetime.now() + timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
            return render_template(
                'login.html',
                error_message="Maximum login attempts reached for this user. Please try again after 1 hour or contact the administrator."
            )

        # Fetch user details, including is_active status
        cursor.execute('SELECT id, password, role, is_active FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()

        if not user:
            session['login_attempts'][username] += 1
            if session['login_attempts'][username] >= 5:
                session['login_block_until'][username] = (datetime.now() + timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
                return render_template(
                    'login.html',
                    error_message="Maximum login attempts reached for this user. Please try again after 1 hour or contact the administrator."
                )
            remaining = 5 - session['login_attempts'][username]
            return render_template('login.html', error_message=f"No account found. Please sign up to create an account. {remaining} attempt(s) left.")

        # Check if the account is inactive
        if user['is_active'] == 0:
            return render_template('login.html', error_message="Your account is inactive. Please contact the administrator.")

        # Verify the password
        if verify_password(password, user['password']):
            user_id, role = user['id'], user['role']
            session['user_id'] = user_id
            session['role'] = role
            session['login_attempts'].pop(username, None)
            session['login_block_until'].pop(username, None)
            create_notification(user_id, "You have successfully logged in.")
            if role == 'student':
                return redirect(url_for('student_menu', user_id=user_id))
            elif role == 'staff':
                return redirect(url_for('staff_menu', user_id=user_id))
            elif role == 'admin':
                return redirect(url_for('admin_menu', user_id=user_id))

        # If the password is incorrect
        session['login_attempts'][username] += 1
        if session['login_attempts'][username] >= 5:
            session['login_block_until'][username] = (datetime.now() + timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
            return render_template(
                'login.html',
                error_message="Maximum login attempts reached for this user. Please try again after 1 hour or contact the administrator."
            )
        remaining = 5 - session['login_attempts'][username]
        error_message = f"Invalid credentials! Please try again. {remaining} attempt(s) left." if remaining > 0 else "Maximum login attempts reached for this user. Please try again after 1 hour or contact the administrator."
        return render_template('login.html', error_message=error_message)
    return render_template('login.html')


@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    success_message = None
    error_message = None

    if request.method == 'POST':
        username = request.form['username']
        old_password = request.form['old_password']
        new_password = request.form['new_password']

        # Validate new password format on the backend
        import re
        password_regex = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>]).{8,}$')
        if not password_regex.match(new_password):
            error_message = "Password must contain at least 8 characters, including uppercase, lowercase, a digit, and a symbol."
            return render_template('change_password.html', error_message=error_message)

        db = get_db()
        cursor = db.cursor(dictionary=True)

        # Fetch the user's current hashed password
        cursor.execute('SELECT password FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()

        if not user:
            error_message = "User not found!"
            return render_template('change_password.html', error_message=error_message)

        # Verify the old password
        stored_hashed_password = user['password']
        if not verify_password(old_password, stored_hashed_password):
            error_message = "Old password is incorrect!"
            return render_template('change_password.html', error_message=error_message)

        # Prevent using the same password as the old one
        if verify_password(new_password, stored_hashed_password):
            error_message = "New password must be different from the old password."
            return render_template('change_password.html', error_message=error_message)

        # Hash the new password and update it in the database
        hashed_password = hash_password(new_password)
        try:
            cursor.execute('UPDATE users SET password = %s WHERE username = %s', (hashed_password, username))
            db.commit()
            success_message = "Password changed successfully!"
            return render_template('change_password.html', success_message=success_message)
        except Error as e:
            error_message = f"Error: {e}"
            return render_template('change_password.html', error_message=error_message)

    return render_template('change_password.html')


@app.route('/logout')
def logout():
    user_id = request.args.get('user_id')
    return redirect(url_for('student_menu', user_id=user_id))


@app.route('/student_menu/<int:user_id>')
def student_menu(user_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    try:
        # Fetch clearance requests for the student
        cursor.execute('''
            SELECT 
                clearance_requests.id AS request_id, 
                departments.name AS department_name, 
                clearance_requests.status, 
                clearance_requests.comments
            FROM clearance_requests
            JOIN departments ON clearance_requests.department_id = departments.id
            WHERE clearance_requests.student_id = %s
        ''', (user_id,))
        results = cursor.fetchall()

        # Check if no clearance requests exist
        if not results:
            flash("No clearance requests found.", "info")

    except Error as e:
        flash(f"Error fetching clearance requests: {e}", "danger")
        results = []

    return render_template('student_menu.html', user_id=user_id, requests=results)


@app.route('/request_clearance', methods=['GET', 'POST'])
def request_clearance():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        # Get student information from the form
        full_name = request.form['fullName']
        id_number = request.form['idNumber']
        department = request.form['department']
        class_year = request.form['classYear']
        last_attended = request.form['lastAttended']
        reason = request.form['reason']
        dept_ids = request.form.getlist('dept_ids')  # List of selected department IDs

        # Validate if the student is registered
        cursor.execute('''
            SELECT id FROM users 
            WHERE username = %s AND id_number = %s AND department_id = 
            (SELECT id FROM departments WHERE name = %s) AND class_year = %s AND role = "student"
        ''', (full_name, id_number, department, class_year))
        student = cursor.fetchone()

        if not student:
            flash("Error: Student not registered. Please check your details.", "danger")
            return render_template('request_clearance.html', departments=get_departments(), user_id=session.get('user_id'))

        student_id = student['id']

        # Check if a similar request already exists for any selected department
        existing_requests = []
        for dept_id in dept_ids:
            cursor.execute('''
                SELECT id FROM clearance_requests 
                WHERE student_id = %s AND department_id = %s AND status = "Pending"
            ''', (student_id, dept_id))
            existing_request = cursor.fetchone()
            if existing_request:
                existing_requests.append(dept_id)

        if existing_requests:
            flash(f"Clearance request already exists for the following department IDs: {', '.join(map(str, existing_requests))}.", "warning")
            return render_template('request_clearance.html', departments=get_departments(), user_id=session.get('user_id'))

        # Insert clearance requests for each selected department
        try:
            for dept_id in dept_ids:
                cursor.execute('''
                    INSERT INTO clearance_requests (student_id, department_id, last_date_class_attended, reason_for_clearance)
                    VALUES (%s, %s, %s, %s)
                ''', (student_id, dept_id, last_attended, reason))
            db.commit()

            # Create a success notification
            create_notification(student_id, "Your clearance request has been submitted successfully.")
            flash("Clearance request successfully sent!", "success")
        except Error as e:
            # Create a failure notification
            create_notification(student_id, "Error: Unable to submit clearance request.")
            flash(f"Error: Unable to submit clearance request. {e}", "danger")

    # Fetch staff departments for the GET request
    departments = get_departments()

    # Pass user_id to the template
    user_id = session.get('user_id')  # Assuming user_id is stored in the session
    return render_template('request_clearance.html', departments=departments, user_id=user_id)

def get_departments():
    """Helper function to fetch staff departments."""
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute('SELECT id, name FROM departments WHERE type = "staff"')
        return cursor.fetchall()
    except Error as e:
        flash(f"Error: Unable to fetch departments. {e}", "danger")
        return []

@app.route('/clear_clearance_request/<int:req_id>', methods=['POST'])
def clear_clearance_request(req_id):
    user_id = request.args.get('user_id')
    db = get_db()
    cursor = db.cursor()

    # Delete the clearance request
    cursor.execute('DELETE FROM clearance_requests WHERE id = %s AND student_id = %s', (req_id, user_id))
    db.commit()

    # Notify the user
    create_notification(user_id, "Your clearance request has been cleared.")
    return redirect(url_for('student_menu', user_id=user_id))


@app.route('/view_clearance_status/<int:user_id>')
def view_clearance_status(user_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    # Fetch the latest clearance request details by joining with the users table
    cursor.execute('''
        SELECT 
            u.username AS full_name,
            u.id_number AS id_number,  -- Correctly fetch the id_number field
            d.name AS department,
            u.class_year,
            cr.last_date_class_attended AS last_attended,
            cr.reason_for_clearance AS reason
        FROM clearance_requests cr
        JOIN users u ON cr.student_id = u.id
        LEFT JOIN departments d ON u.department_id = d.id
        WHERE cr.student_id = %s
        ORDER BY cr.id DESC
        LIMIT 1
    ''', (user_id,))
    clearance_request = cursor.fetchone()

    if not clearance_request:
        # Handle case where no clearance request is found
        return "Error: No clearance request found for this user.", 404

    # Fetch clearance status
    cursor.execute('''
        SELECT 
            d.name AS department,
            cr.status,
            cr.date_of_approval,
            u.username AS approver_name,
            cr.comments
        FROM clearance_requests cr
        LEFT JOIN departments d ON cr.department_id = d.id
        LEFT JOIN users u ON cr.approver_id = u.id
        WHERE cr.student_id = %s
    ''', (user_id,))
    clearances = cursor.fetchall()

    # Pass data to the template
    return render_template(
        'view_clearance_status.html',
        clearance_request=clearance_request,
        clearances=clearances,
        user_id=user_id
    )

@app.route('/staff_menu/<int:user_id>')
def staff_menu(user_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    # Fetch the department ID of the staff member
    cursor.execute('SELECT department_id FROM users WHERE id = %s', (user_id,))
    result = cursor.fetchone()
    if not result or not result['department_id']:
        flash("Error: Staff member is not associated with any department.", "danger")
        return redirect(url_for('home', user_id=user_id))

    department_id = result['department_id']

    # Fetch pending clearance requests for the staff's department with full requester details
    cursor.execute('''
        SELECT 
            cr.id AS request_id, 
            cr.student_id, 
            u.username AS student_name, 
            u.id_number AS student_id_number,
            u.class_year AS student_class_year,
            u.department_id AS student_department_id,
            d_student.name AS student_department,
            cr.reason_for_clearance, 
            cr.last_date_class_attended,
            cr.status,
            cr.comments,
            cr.date_of_approval,
            cr.created_at AS date_submitted
        FROM clearance_requests cr
        JOIN users u ON cr.student_id = u.id
        JOIN departments d_staff ON cr.department_id = d_staff.id
        JOIN departments d_student ON u.department_id = d_student.id
        WHERE cr.department_id = %s AND cr.status = 'Pending'
        ORDER BY cr.id DESC
    ''', (department_id,))
    requests = cursor.fetchall()

    # Check if there are no requests
    if not requests:
        flash("No pending clearance requests for your department.", "info")

    return render_template('staff_menu.html', requests=requests, user_id=user_id)

@app.route('/process_request/<int:req_id>', methods=['GET', 'POST'])
def process_request(req_id):
    user_id = request.args.get('user_id')  # ID of the staff member processing the request
    db = get_db()
    cursor = db.cursor(dictionary=True)

    # Check if the staff member is authorized to process this request
    cursor.execute('SELECT department_id FROM users WHERE id = %s', (user_id,))
    staff_department = cursor.fetchone()
    if not staff_department:
        return "Error: Staff member not found."
    staff_department_id = staff_department['department_id']

    cursor.execute('SELECT department_id FROM clearance_requests WHERE id = %s', (req_id,))
    request_department = cursor.fetchone()
    if not request_department:
        return "Error: Clearance request not found."
    request_department_id = request_department['department_id']

    if staff_department_id != request_department_id:
        return "Access denied. You are not authorized to process this request."

    success_message = None  # Initialize success message
    if request.method == 'POST':
        # Get form data
        status = request.form['status']
        comments = request.form['comments']
        date_of_approval = datetime.now().strftime('%Y-%m-%d')  # Current date

        # Update the clearance request with status, comments, approver_id, and date_of_approval
        cursor.execute('''
            UPDATE clearance_requests
            SET status = %s, comments = %s, approver_id = %s, date_of_approval = %s
            WHERE id = %s
        ''', (status, comments, user_id, date_of_approval, req_id))
        db.commit()

        # Notify the student
        cursor.execute('SELECT student_id FROM clearance_requests WHERE id = %s', (req_id,))
        student = cursor.fetchone()
        if student:
            student_id = student['student_id']
            create_notification(student_id, f"Your clearance request has been processed with status: {status}.")

        # Set success message
        success_message = "Clearance request processed successfully!"

    # Fetch request details for the GET request
    cursor.execute('''
        SELECT cr.id, cr.status, cr.comments, d.name AS department
        FROM clearance_requests cr
        JOIN departments d ON cr.department_id = d.id
        WHERE cr.id = %s
    ''', (req_id,))
    request_info = cursor.fetchone()

    return render_template(
        'process_request.html',
        request_id=req_id,
        request_info=request_info,
        user_id=user_id,
        success_message=success_message
    )

@app.route('/admin_menu/<int:user_id>')
@role_required('admin')
def admin_menu(user_id):
    return render_template('admin_menu.html', user_id=user_id)


@app.route('/manage_users/<int:user_id>')
def manage_users(user_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    # Fetch all users with their roles and departments
    cursor.execute('''
        SELECT 
            u.id, 
            u.username, 
            u.role, 
            u.is_active, 
            d.name AS department 
        FROM users u
        LEFT JOIN departments d ON u.department_id = d.id
    ''')
    users = cursor.fetchall()

    return render_template('manage_users.html', users=users, user_id=user_id)


@app.route('/manage_departments/<int:user_id>')
def manage_departments(user_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    # Fetch all departments
    cursor.execute('SELECT id, name, type FROM departments')
    departments = cursor.fetchall()

    return render_template('manage_departments.html', departments=departments, user_id=user_id)

@app.route('/view_departments/<int:user_id>')
def view_departments(user_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute('SELECT id, name, type FROM departments')
    departments = cursor.fetchall()
    return render_template('view_departments.html', departments=departments, user_id=user_id)

@app.route('/add_department', methods=['GET', 'POST'])
def add_department():
    if request.method == 'POST':
        dept_name = request.form['dept_name'].strip()
        dept_type = request.form['dept_type']
        db = get_db()
        cursor = db.cursor(dictionary=True)
        try:
            # Check if the department already exists (case-insensitive, trimmed)
            cursor.execute(
                'SELECT id FROM departments WHERE LOWER(TRIM(name)) = %s AND type = %s',
                (dept_name.lower(), dept_type)
            )
            existing = cursor.fetchone()
            if existing:
                return render_template(
                    'add_department.html',
                    error_message="This department already exists.",
                    user_id=request.args.get('user_id')
                )
            # Insert the department name and type into the database
            cursor.execute(
                'INSERT INTO departments (name, type) VALUES (%s, %s)',
                (dept_name, dept_type)
            )
            db.commit()
            return render_template(
                'add_department.html',
                success_message="Department added successfully!",
                user_id=request.args.get('user_id')
            )
        except Error as e:
            return render_template(
                'add_department.html',
                error_message=f"Error: {e}",
                user_id=request.args.get('user_id')
            )
    return render_template('add_department.html', user_id=request.args.get('user_id'))

@app.route('/delete_department', methods=['GET', 'POST'])
def delete_department():
    if request.method == 'POST':
        dept_id = request.form['dept_id']
        user_id = request.form.get('user_id')  # Get the user_id from the form data
        if not user_id:
            return render_template('delete_department.html', error_message="Error: user_id is required to delete a department.", user_id=user_id)

        db = get_db()
        cursor = db.cursor()
        try:
            # Check if the department exists before attempting to delete
            cursor.execute('SELECT id FROM departments WHERE id = %s', (dept_id,))
            department = cursor.fetchone()
            if not department:
                return render_template('delete_department.html', error_message=f"Error: Department with ID {dept_id} does not exist.", user_id=user_id)

            # Delete the department
            cursor.execute('DELETE FROM departments WHERE id = %s', (dept_id,))
            db.commit()

            # Pass success message to the template
            return render_template('delete_department.html', success_message="Department deleted successfully!", user_id=user_id)
        except Error as e:
            # Pass error message to the template
            return render_template('delete_department.html', error_message=f"Error: {e}", user_id=user_id)
    else:
        # Pass user_id to the template
        user_id = request.args.get('user_id')
        if not user_id:
            return render_template('delete_department.html', error_message="Error: user_id is required to access this page.")

        # Fetch all departments to display in the dropdown
        db = get_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute('SELECT id, name, type FROM departments')
        departments = cursor.fetchall()

        return render_template('delete_department.html', user_id=user_id, departments=departments)

@app.route('/view_users/<int:user_id>')
def view_users(user_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)
    role_filter = request.args.get('role')

    if role_filter:
        cursor.execute('''
            SELECT 
                u.username, 
                d.name AS department, 
                u.role, 
                u.is_active 
            FROM users u
            LEFT JOIN departments d ON u.department_id = d.id
            WHERE u.role = %s
        ''', (role_filter,))
    else:
        cursor.execute('''
            SELECT 
                u.username, 
                d.name AS department, 
                u.role, 
                u.is_active 
            FROM users u
            LEFT JOIN departments d ON u.department_id = d.id
        ''')
    users = cursor.fetchall()

    return render_template('view_users.html', users=users, user_id=user_id)
@app.route('/reset_user_password', methods=['GET', 'POST'])
def reset_user_password():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        user_id = request.form['username']  # Get the selected user's ID
        new_password = request.form['new_password']

        # Validate new password format
        import re
        password_regex = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>]).{8,}$')
        if not password_regex.match(new_password):
            # Fetch the list of users to display in the dropdown
            cursor.execute('''
                SELECT u.id, u.username, d.name AS department
                FROM users u
                LEFT JOIN departments d ON u.department_id = d.id
            ''')
            users = cursor.fetchall()
            return render_template(
                'reset_user_password.html',
                error_message="Password must contain at least 8 characters, including uppercase, lowercase, a digit, and a symbol.",
                users=users
            )

        hashed_password = hash_password(new_password)  # Hash the new password
        try:
            # Update the user's password in the database
            cursor.execute('UPDATE users SET password = %s WHERE id = %s', (hashed_password, user_id))
            db.commit()

            # Fetch the updated list of users
            cursor.execute('''
                SELECT u.id, u.username, d.name AS department
                FROM users u
                LEFT JOIN departments d ON u.department_id = d.id
            ''')
            users = cursor.fetchall()

            # Pass success message and updated user list to the template
            return render_template(
                'reset_user_password.html',
                success_message="Password reset successfully!",
                users=users
            )
        except Error as e:
            # Fetch the list of users and pass the error message to the template
            cursor.execute('''
                SELECT u.id, u.username, d.name AS department
                FROM users u
                LEFT JOIN departments d ON u.department_id = d.id
            ''')
            users = cursor.fetchall()
            return render_template(
                'reset_user_password.html',
                error_message=f"Error: Unable to reset password. {e}",
                users=users
            )

    # Fetch all users with their departments for the dropdown
    cursor.execute('''
        SELECT u.id, u.username, d.name AS department
        FROM users u
        LEFT JOIN departments d ON u.department_id = d.id
    ''')
    users = cursor.fetchall()
    return render_template('reset_user_password.html', users=users)

@app.route('/delete_user_account/<int:user_id>', methods=['GET', 'POST'])
def delete_user_account(user_id):
    try:
        db = get_db()  # Ensure the database connection is initialized
        cursor = db.cursor(dictionary=True)

        if request.method == 'POST':
            user_id_to_delete = request.form['user_id']  # Get the selected user ID from the form
            try:
                # Delete the user from the database
                cursor.execute('DELETE FROM users WHERE id = %s', (user_id_to_delete,))
                db.commit()
                # Fetch the updated list of users
                cursor.execute('SELECT id, username, role FROM users')
                users = cursor.fetchall()
                # Pass success message and updated user list to the template
                return render_template('delete_user_account.html', success_message="User account deleted successfully!", users=users, user_id=user_id)
            except Error as e:
                # Pass error message to the template
                cursor.execute('SELECT id, username, role FROM users')
                users = cursor.fetchall()
                return render_template('delete_user.html', error_message=f"Error: Unable to delete user. {e}", users=users, user_id=user_id)

        # Fetch the list of users to display in the dropdown
        cursor.execute('SELECT id, username, role FROM users')
        users = cursor.fetchall()
        return render_template('delete_user_account.html', users=users, user_id=user_id)

    except Error as e:
        return render_template('delete_user_account.html', error_message=f"Error: Unable to connect to the database. {e}", user_id=user_id)


@app.route('/deactivate_user_account', methods=['GET', 'POST'])
def deactivate_user_account():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        user_id_to_deactivate = request.form['user_id']
        try:
            # Deactivate the user account
            cursor.execute('UPDATE users SET is_active = 0 WHERE id = %s', (user_id_to_deactivate,))
            db.commit()
            # Flash success message
            flash("User account deactivated successfully!", "success")
            return redirect(url_for('deactivate_user_account'))
        except Error as e:
            # Flash error message
            flash(f"Error: Unable to deactivate user. {e}", "danger")

    # Fetch active users to display in the dropdown
    cursor.execute('SELECT id, username, role FROM users WHERE is_active = 1')
    users = cursor.fetchall()
    return render_template('deactivate_user_account.html', users=users)


@app.route('/activate_user_account', methods=['GET', 'POST'])
@role_required('admin')  # Ensure only admins can access this route
def activate_user_account():
    db = get_db()
    cursor = db.cursor(dictionary=True)  # Use dictionary=True to fetch results as dictionaries

    if request.method == 'POST':
        user_id_to_activate = request.form['user_id']  # Get the selected user ID from the form
        try:
            # Set the is_active column to 1 for the selected user
            cursor.execute('UPDATE users SET is_active = 1 WHERE id = %s', (user_id_to_activate,))
            db.commit()
            # Fetch the updated list of inactive users
            cursor.execute('SELECT id, username, role FROM users WHERE is_active = 0')
            users = cursor.fetchall()
            # Pass success message and updated user list to the template
            return render_template('activate_user_account.html', success_message="User account activated successfully!", users=users, user_id=session.get('user_id'))
        except Error as e:
            # Fetch the list of inactive users and pass the error message to the template
            cursor.execute('SELECT id, username, role FROM users WHERE is_active = 0')
            users = cursor.fetchall()
            return render_template('activate_user_account.html', error_message=f"Error: Unable to activate user. {e}", users=users, user_id=session.get('user_id'))

    # Fetch inactive users to display in the dropdown
    cursor.execute('SELECT id, username, role FROM users WHERE is_active = 0')
    users = cursor.fetchall()
    return render_template('activate_user_account.html', users=users, user_id=session.get('user_id'))


@app.route('/add_user_account', methods=['GET', 'POST'])
@role_required('admin')  # Ensure only admins can access this route
def add_user_account():
    db = get_db()
    cursor = db.cursor()

    success_message = None  # Initialize success_message

    if request.method == 'POST':
        username = request.form['username']
        sex = request.form.get('sex')  # Get the sex field from the form
        password = request.form['password']
        confirm_password = request.form.get('confirm_password')
        role = request.form['role'].lower()
        department_id = request.form.get('student_department') if role == 'student' else request.form.get('department_id')
        class_year = request.form.get('class') if role == 'student' else None
        id_number = request.form.get('id_number') if role == 'student' else None

        # Validate password complexity
        password_regex = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'
        if not re.match(password_regex, password):
            cursor.execute('SELECT id, name, type FROM departments')
            departments = cursor.fetchall()
            return render_template(
                'add_user_account.html',
                error_message="Password must contain at least one uppercase letter, one lowercase letter, one digit, one special character, and be at least 8 characters long.",
                departments=departments,
                user_id=session.get('user_id')
            )

        # Validate password confirmation
        if confirm_password is not None and password != confirm_password:
            cursor.execute('SELECT id, name, type FROM departments')
            departments = cursor.fetchall()
            return render_template(
                'add_user_account.html',
                error_message="Passwords do not match!",
                departments=departments,
                user_id=session.get('user_id')
            )

        # Validate ID Number format for students
        if role == 'student' and id_number:
            # Require at least 3 digits before slash, at least 2 digits after slash, and first after-slash digit >= 1
            id_number_regex = r'^\d{3,}/[1-9]\d+$'
            if not re.match(id_number_regex, id_number):
                cursor.execute('SELECT id, name, type FROM departments')
                departments = cursor.fetchall()
                return render_template(
                    'add_user_account.html',
                    error_message="ID Number must be in the format 123/45 or longer (at least 3 digits before the slash, at least 2 digits after the slash, and the first digit after the slash must be 1 or greater).",
                    departments=departments,
                    user_id=session.get('user_id')
                )

        try:
            # Restrict the system to only one admin account
            if role == 'admin':
                cursor.execute('SELECT COUNT(*) FROM users WHERE role = "admin"')
                admin_count = cursor.fetchone()[0]
                if admin_count >= 1:
                    cursor.execute('SELECT id, name, type FROM departments')
                    departments = cursor.fetchall()
                    return render_template(
                        'add_user_account.html',
                        error_message="The system already has an admin.",
                        departments=departments,
                        user_id=session.get('user_id')
                    )

            # Check if an identical account already exists
            cursor.execute('''
                SELECT * FROM users 
                WHERE username = %s AND role = %s AND department_id = %s AND class_year = %s AND id_number = %s
            ''', (username, role, department_id, class_year, id_number))
            identical_user = cursor.fetchone()
            if identical_user:
                cursor.execute('SELECT id, name, type FROM departments')
                departments = cursor.fetchall()
                return render_template(
                    'add_user_account.html',
                    error_message="An account already exists!",
                    departments=departments,
                    user_id=session.get('user_id')
                )

            # Insert the new user into the database, now including sex
            hashed_password = hash_password(password)
            cursor.execute('''
                INSERT INTO users (username, sex, password, role, department_id, class_year, id_number)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            ''', (username, sex, hashed_password, role, department_id, class_year, id_number))
            db.commit()
            cursor.execute('SELECT id, name, type FROM departments')
            departments = cursor.fetchall()
            success_message = "User account added successfully!"
            return render_template(
                'add_user_account.html',
                success_message=success_message,
                departments=departments,
                user_id=session.get('user_id')
            )
        except Error as e:
            cursor.execute('SELECT id, name, type FROM departments')
            departments = cursor.fetchall()
            return render_template(
                'add_user_account.html',
                error_message=f"Error registering the user: {e}",
                departments=departments,
                user_id=session.get('user_id')
            )

    # Fetch departments for the dropdown
    cursor.execute('SELECT id, name, type FROM departments')
    departments = cursor.fetchall()
    return render_template('add_user_account.html', departments=departments, user_id=session.get('user_id'))

@app.route('/notifications/<int:user_id>')
def notifications(user_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    # Fetch notifications for the user, ordered by most recent
    cursor.execute('''
        SELECT id, message, is_read
        FROM notifications
        WHERE user_id = %s
        ORDER BY id DESC
    ''', (user_id,))
    notifications = cursor.fetchall()

    return render_template('notifications.html', notifications=notifications, user_id=user_id)

# --- Example usage of notifications for user activities ---

# For student: after successful clearance request
def request_clearance_success(student_id):
    create_notification(student_id, "Your clearance request has been submitted successfully.")

# For student: after changing password
def password_changed_success(user_id):
    create_notification(user_id, "Your password was changed successfully.")

# For staff: after approving/rejecting a clearance request
def clearance_processed(student_id, status):
    create_notification(student_id, f"Your clearance request has been {status.lower()} by staff.")

# For admin: after adding a user
def user_added_success(user_id):
    create_notification(user_id, "A new user account has been created for you.")

# You should call these helper functions at the appropriate place in your routes,
# for example after a successful action, to notify the user of the activity.


@app.route('/mark_as_read/<int:notif_id>')
def mark_as_read(notif_id):
    db = get_db()
    cursor = db.cursor()
    cursor.execute('UPDATE notifications SET is_read = 1 WHERE id = %s', (notif_id,))
    db.commit()
    user_id = request.args.get('user_id')
    return redirect(url_for('notifications', user_id=user_id))


@app.route('/clear_notification/<int:notif_id>', methods=['POST'])
def clear_notification(notif_id):
    user_id = request.args.get('user_id')
    db = get_db()
    cursor = db.cursor()
    cursor.execute('DELETE FROM notifications WHERE id = %s AND user_id = %s', (notif_id, user_id))
    db.commit()
    return redirect(url_for('notifications', user_id=user_id))

@app.route('/all_notifications/<int:user_id>')
@role_required('admin')
def all_notifications(user_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    # Verify if the user is an admin
    cursor.execute('SELECT role FROM users WHERE id = %s', (user_id,))
    user_role = cursor.fetchone()
    if not user_role or user_role['role'] != 'admin':
        return "Access denied. Only admins can view all notifications."

    # Fetch all notifications/activity logs with user info
    cursor.execute('''
        SELECT 
            n.id AS notification_id, 
            u.username AS user, 
            n.message AS activity, 
            n.is_read AS read_status, 
            n.created_at AS timestamp
        FROM notifications n
        JOIN users u ON n.user_id = u.id
        ORDER BY n.created_at DESC
    ''')
    notifications = cursor.fetchall()

    # Optionally, fetch a list of all users for filtering (for future extension)
    cursor.execute('SELECT id, username FROM users ORDER BY username')
    users_list = cursor.fetchall()

    return render_template(
        'all_notifications.html',
        notifications=notifications,
        users=users_list,
        user_id=user_id
    )

if __name__ == '__main__':
    app.run(debug=True)                                          